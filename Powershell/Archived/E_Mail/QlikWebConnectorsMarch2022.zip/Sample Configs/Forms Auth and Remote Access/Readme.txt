﻿This is a sample deploy.config and associated logins.xml file to configure Qlik Web Connectors
for Forms Authentication, with remote access allowed and with the most secure password 
management system currently available in the product (SaltedPBKDF2SHA1PasswordChecker).

If you copy the logins.xml and deploy.config files over those in the root Qlik Web Connectors 
directory (you may wish to take a copy of the existing files first), when you then launch 
Qlik Web Connectors you should find you can login with either:

admin@yourdomain.com
password01

Or:
user@yourdomain.com
password01

You can edit the <Username> element in logins.xml to be your own username or email address.
The first user has admin privileges.
Once logged in as Admin, you can go to the user management screen to add or edit users.